package com.lumi.block;

import net.minecraft.world.level.block.LanternBlock;

/** Linterna de estrella: se comporta como la linterna normal (colgada o apoyada, con agua). */
public class StarLanternBlock extends LanternBlock {
    public StarLanternBlock(Properties properties) {
        super(properties);
    }
}
