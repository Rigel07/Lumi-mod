package com.lumi.item;

import com.lumi.LumiMod;
import com.lumi.block.StarLightBlock;
import com.lumi.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

/** La armadura luminica deja un rastro de luz: cada pieza puesta aumenta la intensidad. */
@Mod.EventBusSubscriber(modid = LumiMod.MODID)
public final class ArmorLightEvents {
    private ArmorLightEvents() {}

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER
                || event.player.tickCount % 4 != 0) {
            return;
        }
        Player player = event.player;
        int pieces = LuminicArmorItem.countWorn(player);
        if (pieces == 0) {
            return;
        }
        Level level = player.level();
        BlockPos pos = player.blockPosition().above();
        if (!level.getBlockState(pos).isAir()) {
            pos = player.blockPosition();
        }
        if (!level.getBlockState(pos).isAir()) {
            return;
        }
        int lightLevel = Math.min(15, 4 + 3 * pieces);
        level.setBlock(pos, ModBlocks.STAR_LIGHT.get().defaultBlockState()
                .setValue(StarLightBlock.LEVEL, lightLevel), 3);
    }
}
