package com.lumi.item;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Pieza de la armadura luminica: cada pieza puesta aumenta la luz que deja a su paso. */
public class LuminicArmorItem extends ArmorItem {
    public LuminicArmorItem(ArmorMaterial material, ArmorItem.Type type, Item.Properties properties) {
        super(material, type, properties);
    }

    /** Numero de piezas luminicas (0-4) que lleva puestas la entidad. */
    public static int countWorn(LivingEntity entity) {
        int count = 0;
        for (ItemStack stack : entity.getArmorSlots()) {
            if (stack.getItem() instanceof LuminicArmorItem) {
                count++;
            }
        }
        return count;
    }
}
