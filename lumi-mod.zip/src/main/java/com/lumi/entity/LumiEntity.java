package com.lumi.entity;

import com.lumi.block.StarLightBlock;
import com.lumi.registry.ModBlocks;
import com.lumi.registry.ModItems;
import com.lumi.registry.ModSounds;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * Lumi: estrellita amable que flota, brilla de colores, se acerca a todo lo que ve
 * y suelta de vez en cuando un fragmento de estrella. Aparece de noche.
 */
public class LumiEntity extends PathfinderMob {
    /** 0 = amarillo, 1 = verde, 2 = azul, 3 = rosa. */
    public static final int VARIANTS = 4;

    private static final Vector3f[] COLORS = {
            new Vector3f(1.0F, 0.90F, 0.30F),
            new Vector3f(0.40F, 1.0F, 0.50F),
            new Vector3f(0.40F, 0.70F, 1.0F),
            new Vector3f(1.0F, 0.55F, 0.80F)
    };

    private static final EntityDataAccessor<Integer> DATA_VARIANT =
            SynchedEntityData.defineId(LumiEntity.class, EntityDataSerializers.INT);

    private int fragmentTimer;

    public LumiEntity(EntityType<? extends LumiEntity> type, Level level) {
        super(type, level);
        this.moveControl = new FlyingMoveControl(this, 20, true);
        this.setNoGravity(true);
        this.fragmentTimer = nextFragmentDelay(this.random);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 6.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.15D)
                .add(Attributes.FLYING_SPEED, 0.4D);
    }

    /** Solo aparece de noche y a cielo abierto. */
    public static boolean checkLumiSpawnRules(EntityType<LumiEntity> type, ServerLevelAccessor level,
                                              MobSpawnType reason, BlockPos pos, RandomSource random) {
        if (reason != MobSpawnType.NATURAL && reason != MobSpawnType.CHUNK_GENERATION) {
            return true;
        }
        return isNightTime(level.getLevel()) && level.canSeeSky(pos);
    }

    public static boolean isNightTime(Level level) {
        long time = level.getDayTime() % 24000L;
        return time >= 12500L && time <= 23500L;
    }

    private static int nextFragmentDelay(RandomSource random) {
        return 2400 + random.nextInt(3600);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.4D));
        this.goalSelector.addGoal(2, new ApproachFriendsGoal(this));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomFlyingGoal(this, 0.8D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation navigation = new FlyingPathNavigation(this, level);
        navigation.setCanOpenDoors(false);
        navigation.setCanFloat(true);
        navigation.setCanPassDoors(true);
        return navigation;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_VARIANT, 0);
    }

    public int getVariant() {
        return this.entityData.get(DATA_VARIANT) & (VARIANTS - 1);
    }

    public void setVariant(int variant) {
        this.entityData.set(DATA_VARIANT, variant & (VARIANTS - 1));
    }

    @Override
    @Nullable
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, @Nullable SpawnGroupData data,
                                        @Nullable CompoundTag tag) {
        this.setVariant(this.random.nextInt(VARIANTS));
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", this.getVariant());
        tag.putInt("FragmentTimer", this.fragmentTimer);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setVariant(tag.getInt("Variant"));
        if (tag.contains("FragmentTimer")) {
            this.fragmentTimer = tag.getInt("FragmentTimer");
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            if (this.random.nextInt(3) == 0) {
                Vector3f color = COLORS[this.getVariant()];
                this.level().addParticle(new DustParticleOptions(color, 0.8F),
                        this.getX() + (this.random.nextDouble() - 0.5D) * 0.5D,
                        this.getY() + 0.25D + (this.random.nextDouble() - 0.5D) * 0.5D,
                        this.getZ() + (this.random.nextDouble() - 0.5D) * 0.5D,
                        0.0D, 0.0D, 0.0D);
            }
            return;
        }

        // suelta un fragmento de estrella cada cierto tiempo
        if (--this.fragmentTimer <= 0) {
            this.fragmentTimer = nextFragmentDelay(this.random);
            this.spawnAtLocation(new ItemStack(ModItems.STAR_FRAGMENT.get()));
            this.playSound(ModSounds.LUMI_FRAGMENT.get(), 0.8F, 1.0F);
            if (this.level() instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.END_ROD, this.getX(), this.getY() + 0.2D, this.getZ(),
                        10, 0.25D, 0.25D, 0.25D, 0.02D);
            }
        }

        // ilumina suavemente a su alrededor
        if (this.tickCount % 8 == 0) {
            BlockPos pos = this.blockPosition();
            if (this.level().getBlockState(pos).isAir()) {
                this.level().setBlock(pos, ModBlocks.STAR_LIGHT.get().defaultBlockState()
                        .setValue(StarLightBlock.LEVEL, 9), 3);
            }
        }

        // al amanecer se desvanecen
        if (this.tickCount > 400 && !isNightTime(this.level()) && !this.isPersistenceRequired()
                && !this.hasCustomName() && this.random.nextInt(300) == 0) {
            if (this.level() instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.END_ROD, this.getX(), this.getY() + 0.2D, this.getZ(),
                        14, 0.3D, 0.3D, 0.3D, 0.03D);
            }
            this.discard();
        }
    }

    /** Una caricia (mano vacia): suena, brilla y suelta corazones. */
    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (player.getItemInHand(hand).isEmpty()) {
            if (!this.level().isClientSide && this.level() instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 0.5D, this.getZ(),
                        3, 0.2D, 0.2D, 0.2D, 0.0D);
                this.level().playSound(null, this.blockPosition(), ModSounds.LUMI_AMBIENT.get(),
                        SoundSource.NEUTRAL, 0.9F, 1.15F);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
    }

    @Override
    public boolean isPushedByFluid() {
        return false;
    }

    @Override
    public int getAmbientSoundInterval() {
        return 200;
    }

    @Override
    protected float getSoundVolume() {
        return 0.7F;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.LUMI_AMBIENT.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.LUMI_HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.LUMI_DEATH.get();
    }

    /** Se acerca con carino a cualquier ser vivo que vea, se queda cerca y gira despacio a su alrededor. */
    private static class ApproachFriendsGoal extends Goal {
        private final LumiEntity lumi;
        private LivingEntity target;
        private int recalc;
        private int patience;

        ApproachFriendsGoal(LumiEntity lumi) {
            this.lumi = lumi;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (this.lumi.getRandom().nextInt(10) != 0) {
                return false;
            }
            AABB area = this.lumi.getBoundingBox().inflate(14.0D);
            List<LivingEntity> candidates = this.lumi.level().getEntitiesOfClass(LivingEntity.class, area,
                    e -> e != this.lumi && !(e instanceof LumiEntity) && e.isAlive() && !e.isInvisible()
                            && !(e instanceof Player player && player.isSpectator())
                            && this.lumi.hasLineOfSight(e));
            this.target = candidates.stream()
                    .min(Comparator.comparingDouble(e -> e.distanceToSqr(this.lumi)))
                    .orElse(null);
            return this.target != null;
        }

        @Override
        public boolean canContinueToUse() {
            return this.target != null && this.target.isAlive() && this.patience > 0
                    && this.lumi.distanceToSqr(this.target) < 24.0D * 24.0D;
        }

        @Override
        public void start() {
            this.patience = 200 + this.lumi.getRandom().nextInt(200);
            this.recalc = 0;
        }

        @Override
        public void tick() {
            this.patience--;
            this.lumi.getLookControl().setLookAt(this.target, 30.0F, 30.0F);
            double distance = this.lumi.distanceTo(this.target);
            if (distance > 2.5D) {
                if (--this.recalc <= 0) {
                    this.recalc = 8;
                    this.lumi.getNavigation().moveTo(this.target.getX(),
                            this.target.getY() + this.target.getBbHeight() * 0.8D + 0.4D,
                            this.target.getZ(), 1.0D);
                }
            } else {
                this.lumi.getNavigation().stop();
                Vec3 offset = new Vec3(this.target.getX() - this.lumi.getX(), 0.0D, this.target.getZ() - this.lumi.getZ());
                if (offset.lengthSqr() > 1.0E-4D) {
                    Vec3 sideways = new Vec3(-offset.z, 0.0D, offset.x).normalize().scale(0.02D);
                    this.lumi.setDeltaMovement(this.lumi.getDeltaMovement().add(sideways));
                }
            }
        }

        @Override
        public void stop() {
            this.target = null;
            this.lumi.getNavigation().stop();
        }
    }
}
