package com.lumi.client;

import com.lumi.LumiMod;
import com.lumi.entity.LumiEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

public class LumiRenderer extends MobRenderer<LumiEntity, LumiModel> {
    private static final ResourceLocation[] TEXTURES = {
            texture("yellow"), texture("green"), texture("blue"), texture("pink")
    };

    public LumiRenderer(EntityRendererProvider.Context context) {
        super(context, new LumiModel(context.bakeLayer(LumiModel.LAYER_LOCATION)), 0.2F);
    }

    private static ResourceLocation texture(String color) {
        return new ResourceLocation(LumiMod.MODID, "textures/entity/lumi_" + color + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(LumiEntity entity) {
        return TEXTURES[entity.getVariant()];
    }

    /** Las estrellas brillan siempre al maximo, incluso en plena oscuridad. */
    @Override
    protected int getBlockLightLevel(LumiEntity entity, BlockPos pos) {
        return 15;
    }

    @Override
    protected void scale(LumiEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.3F, 1.3F, 1.3F);
    }
}
