package com.lumi.client;

import com.lumi.LumiMod;
import com.lumi.entity.LumiEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Estrellita de cinco puntas: nucleo con carita, punta superior, dos brazos y dos piernas. */
public class LumiModel extends EntityModel<LumiEntity> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(LumiMod.MODID, "lumi"), "main");

    private final ModelPart root;
    private final ModelPart star;
    private final ModelPart armLeft;
    private final ModelPart armRight;
    private final ModelPart legLeft;
    private final ModelPart legRight;

    public LumiModel(ModelPart root) {
        this.root = root;
        this.star = root.getChild("star");
        this.armLeft = this.star.getChild("arm_left");
        this.armRight = this.star.getChild("arm_right");
        this.legLeft = this.star.getChild("leg_left");
        this.legRight = this.star.getChild("leg_right");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition star = root.addOrReplaceChild("star",
                CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -3.0F, -1.5F, 6.0F, 6.0F, 3.0F),
                PartPose.offset(0.0F, 19.0F, 0.0F));

        star.addOrReplaceChild("top",
                CubeListBuilder.create().texOffs(18, 0).addBox(-1.5F, -3.0F, -1.5F, 3.0F, 3.0F, 3.0F),
                PartPose.offset(0.0F, -3.0F, 0.0F));

        star.addOrReplaceChild("arm_left",
                CubeListBuilder.create().texOffs(0, 9).addBox(-3.0F, -1.5F, -1.5F, 3.0F, 3.0F, 3.0F),
                PartPose.offsetAndRotation(-3.0F, -1.0F, 0.0F, 0.0F, 0.0F, 0.55F));
        star.addOrReplaceChild("arm_right",
                CubeListBuilder.create().texOffs(12, 9).addBox(0.0F, -1.5F, -1.5F, 3.0F, 3.0F, 3.0F),
                PartPose.offsetAndRotation(3.0F, -1.0F, 0.0F, 0.0F, 0.0F, -0.55F));

        star.addOrReplaceChild("leg_left",
                CubeListBuilder.create().texOffs(0, 15).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 4.0F, 3.0F),
                PartPose.offsetAndRotation(-1.8F, 3.0F, 0.0F, 0.0F, 0.0F, 0.4F));
        star.addOrReplaceChild("leg_right",
                CubeListBuilder.create().texOffs(12, 15).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 4.0F, 3.0F),
                PartPose.offsetAndRotation(1.8F, 3.0F, 0.0F, 0.0F, 0.0F, -0.4F));

        return LayerDefinition.create(mesh, 32, 32);
    }

    @Override
    public void setupAnim(LumiEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        this.star.y = 19.0F + Mth.sin(ageInTicks * 0.1F) * 0.8F;
        this.star.zRot = Mth.sin(ageInTicks * 0.07F) * 0.08F;
        this.star.yRot = netHeadYaw * ((float) Math.PI / 180.0F) * 0.5F;
        this.star.xRot = headPitch * ((float) Math.PI / 180.0F) * 0.3F;

        float wiggle = Mth.sin(ageInTicks * 0.2F) * 0.15F;
        this.armLeft.zRot = 0.55F + wiggle;
        this.armRight.zRot = -0.55F - wiggle;
        this.legLeft.zRot = 0.4F - wiggle * 0.7F;
        this.legRight.zRot = -0.4F + wiggle * 0.7F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
