package com.lumi;

import com.lumi.registry.ModBlocks;
import com.lumi.registry.ModCreativeTabs;
import com.lumi.registry.ModEntities;
import com.lumi.registry.ModItems;
import com.lumi.registry.ModSounds;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(LumiMod.MODID)
public class LumiMod {
    public static final String MODID = "lumi";

    public LumiMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITY_TYPES.register(modBus);
        ModSounds.SOUNDS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
    }
}
