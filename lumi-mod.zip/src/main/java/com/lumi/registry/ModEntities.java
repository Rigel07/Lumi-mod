package com.lumi.registry;

import com.lumi.LumiMod;
import com.lumi.entity.LumiEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, LumiMod.MODID);

    /** Categoria AMBIENT: aparece (y se va) de forma continua durante la noche, como los murcielagos. */
    public static final RegistryObject<EntityType<LumiEntity>> LUMI = ENTITY_TYPES.register("lumi",
            () -> EntityType.Builder.<LumiEntity>of(LumiEntity::new, MobCategory.AMBIENT)
                    .sized(0.5F, 0.5F)
                    .clientTrackingRange(10)
                    .build(LumiMod.MODID + ":lumi"));

    private ModEntities() {}
}
