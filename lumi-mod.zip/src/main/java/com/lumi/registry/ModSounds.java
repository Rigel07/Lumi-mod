package com.lumi.registry;

import com.lumi.LumiMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, LumiMod.MODID);

    public static final RegistryObject<SoundEvent> LUMI_AMBIENT = register("entity.lumi.ambient");
    public static final RegistryObject<SoundEvent> LUMI_HURT = register("entity.lumi.hurt");
    public static final RegistryObject<SoundEvent> LUMI_DEATH = register("entity.lumi.death");
    public static final RegistryObject<SoundEvent> LUMI_FRAGMENT = register("entity.lumi.fragment");

    private ModSounds() {}

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(LumiMod.MODID, name)));
    }
}
