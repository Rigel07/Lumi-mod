package com.lumi.registry;

import com.lumi.LumiMod;
import com.lumi.item.LuminicArmorItem;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, LumiMod.MODID);

    public static final RegistryObject<Item> STAR_FRAGMENT = ITEMS.register("star_fragment",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON)));

    public static final RegistryObject<Item> STAR_LANTERN = ITEMS.register("star_lantern",
            () -> new BlockItem(ModBlocks.STAR_LANTERN.get(), new Item.Properties()));

    public static final RegistryObject<Item> LUMINIC_HELMET = armor("luminic_helmet", ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> LUMINIC_CHESTPLATE = armor("luminic_chestplate", ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> LUMINIC_LEGGINGS = armor("luminic_leggings", ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> LUMINIC_BOOTS = armor("luminic_boots", ArmorItem.Type.BOOTS);

    public static final RegistryObject<Item> LUMI_SPAWN_EGG = ITEMS.register("lumi_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.LUMI, 0xFFE680, 0xFF9AD5, new Item.Properties()));

    private ModItems() {}

    private static RegistryObject<Item> armor(String name, ArmorItem.Type type) {
        return ITEMS.register(name,
                () -> new LuminicArmorItem(ModArmorMaterials.LUMINIC, type, new Item.Properties().rarity(Rarity.UNCOMMON)));
    }
}
