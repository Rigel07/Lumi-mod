package com.lumi.registry;

import com.lumi.LumiMod;
import com.lumi.block.StarLanternBlock;
import com.lumi.block.StarLightBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, LumiMod.MODID);

    /** Linterna de estrella: luz maxima, se puede colgar o apoyar. */
    public static final RegistryObject<Block> STAR_LANTERN = BLOCKS.register("star_lantern",
            () -> new StarLanternBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.GOLD)
                    .strength(2.0F)
                    .sound(SoundType.LANTERN)
                    .lightLevel(state -> 15)
                    .noOcclusion()
                    .pushReaction(PushReaction.DESTROY)));

    /** Bloque de luz invisible y temporal: lo dejan los Lumi y la armadura luminica. */
    public static final RegistryObject<Block> STAR_LIGHT = BLOCKS.register("star_light",
            () -> new StarLightBlock(BlockBehaviour.Properties.of()
                    .replaceable()
                    .noCollission()
                    .noOcclusion()
                    .strength(-1.0F, 3600000.8F)
                    .lightLevel(state -> state.getValue(StarLightBlock.LEVEL))
                    .pushReaction(PushReaction.DESTROY)));

    private ModBlocks() {}
}
