package com.lumi.registry;

import com.lumi.LumiMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LumiMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("lumi",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.lumi"))
                    .icon(() -> new ItemStack(ModItems.STAR_FRAGMENT.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.LUMI_SPAWN_EGG.get());
                        output.accept(ModItems.STAR_FRAGMENT.get());
                        output.accept(ModItems.STAR_LANTERN.get());
                        output.accept(ModItems.LUMINIC_HELMET.get());
                        output.accept(ModItems.LUMINIC_CHESTPLATE.get());
                        output.accept(ModItems.LUMINIC_LEGGINGS.get());
                        output.accept(ModItems.LUMINIC_BOOTS.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
