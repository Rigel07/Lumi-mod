# Lumi (Forge 1.20.1)

Mod para Minecraft Forge 1.20.1 (Forge 47.2.0, Java 17).

## Lumi, la estrellita
- Pequeña estrella muy cute que **aparece de noche** (a cielo abierto, en grupitos de 2 a 4) y se desvanece al amanecer.
- Brilla en **amarillo, verde, azul o rosa**, siempre a máxima luz, y deja chispitas de color.
- Es muy amable: **se acerca a todo lo que ve** (jugadores, animales, aldeanos...) y se queda dando vueltas despacito a su lado.
- Flota, no se hace daño al caer y, mientras vuela, **ilumina suavemente** a su alrededor.
- **Suelta un Fragmento de Estrella** cada 2 a 5 minutos aprox.
- Un clic con la mano vacía le hace una caricia (corazones y su canto).
- **Sonido propio y tranquilizador**: campanitas suaves con eco (tres variantes al cantar, sonido de susto, de despedida y de cuando suelta un fragmento).
- Con una etiqueta (name tag) no se desvanece al amanecer.

## Fragmento de Estrella y lo que se fabrica
- **Linterna de Estrella** (luz 15, se apoya o se cuelga): 8 pepitas de hierro + 1 fragmento en el centro.
- **Armadura Lumínica** (protección entre el hierro y el oro, encantable): 
  - Casco: `FGF / F F`
  - Peto: `F F / FGF / FFF`
  - Pantalones: `FFF / FGF / F F`
  - Botas: `F F / FGF`
  (F = Fragmento de Estrella, G = lingote de oro). Se repara con fragmentos.
- **Deja luz a su paso**: cada pieza puesta aumenta la luz del rastro (1 pieza = 7, set completo = 15). La luz se queda mientras estés cerca y se apaga sola cuando te vas.

## Ajustes
- Frecuencia de aparición: `src/main/resources/data/lumi/forge/biome_modifier/lumi_spawns.json` (`weight`, `minCount`, `maxCount`).
- Ritmo de fragmentos: `nextFragmentDelay` en `LumiEntity.java` (ahora 2400 + hasta 3600 ticks).

## Compilar con GitHub (sin instalar nada)
1. Sube a un repositorio **este .zip tal cual** (sin descomprimir) y el archivo `.github/workflows/build.yml`
   (créalo con *Add file → Create new file* escribiendo la ruta `.github/workflows/build.yml`).
2. GitHub descomprime el zip, compila y deja el `.jar` en **Actions → último run → Artifacts → mod-jar**.
3. Copia el `.jar` a la carpeta `mods` de Forge 1.20.1.

Compilar en local: `gradle build` (Gradle 8.1.1, JDK 17). El jar queda en `build/libs/`.
